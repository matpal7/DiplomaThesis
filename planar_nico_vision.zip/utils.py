import glob
import os

import numpy as np
import cv2


def load_calib_data(npy_path):
    calib_dict = np.load(npy_path, allow_pickle=True).flat[0]
    return calib_dict


def get_l_r_image_fnames(calib_img_folder, max_imgs=None):
    glob_string_l = '{}/*l*.png'.format(calib_img_folder)
    glob_string_r = '{}/*r*.png'.format(calib_img_folder)
    images_l = sorted(glob.glob(glob_string_l))
    images_r = sorted(glob.glob(glob_string_r))

    if max_imgs is not None:
        images_l = images_l[:max_imgs]
        images_r = images_r[:max_imgs]

    return images_l, images_r