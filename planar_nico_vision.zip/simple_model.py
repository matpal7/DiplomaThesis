import sys

import cv2
import numpy as np
import poselib
import pyceres
import pycolmap
from matplotlib import pyplot as plt

from image import load_l_r_images_undistorted, extract_descriptors
from utils import load_calib_data

# sys.path.insert(0, "D:/Research/code/ceres_python_bindings/build/Release")
# import PyCeres

class ReconstructionModel():
    def __init__(self, calib_path):
        self.calib_dict = load_calib_data(calib_path)
        self.imgs = {'left': [], 'right': []}
        self.processed_imgs = {'left': 0, 'right': 0}
        self.X = []
        self.poses = []
        self.tol = 5.0
        self.rig_pose = [None]

        self.camera_l = pycolmap.Camera(model='PINHOLE', id = 0,
                                        width= self.calib_dict['img_dim_l'][1], height=self.calib_dict['img_dim_l'][0],
                                        params=np.array([self.calib_dict['new_K_l'][0, 2], self.calib_dict['new_K_l'][1, 2],
                                                         self.calib_dict['new_K_l'][0, 0], self.calib_dict['new_K_l'][1, 1]]))

        self.camera_r = pycolmap.Camera(model='PINHOLE', id = 0,
                                        width= self.calib_dict['img_dim_r'][1], height=self.calib_dict['img_dim_r'][0],
                                        params=np.array([self.calib_dict['new_K_r'][0, 2], self.calib_dict['new_K_r'][1, 2],
                                                         self.calib_dict['new_K_r'][0, 0], self.calib_dict['new_K_r'][1, 1]]))

        self.update()

    def update(self):
        self.camera_l_dict = {'model': self.camera_l.model_name,
                              'width': self.camera_l.width, 'height': self.camera_l.height,
                              'params': self.camera_l.params}

        self.camera_r_dict = {'model': self.camera_r.model_name,
                              'width': self.camera_r.width, 'height': self.camera_r.height,
                              'params': self.camera_r.params}

    def load_images(self, img_dir):
        self.imgs['left'], self.imgs['right'] = load_l_r_images_undistorted(self.calib_dict, img_dir, correct_horizon=False)
        extract_descriptors(self.imgs['left'])
        extract_descriptors(self.imgs['right'])
        # extract_descriptors(self.imgs['right'])

    def reconstruct(self):
        self.init_pose()
        # self.visualize()
        self.bundle_adjust()
        # self.visualize()
        self.retriangulate()
        # self.visualize()
        while self.processed_imgs['left'] < len(self.imgs['left']):
            self.add_next_view()
            # self.visualize()
            self.bundle_adjust()
            # self.visualize()
            self.retriangulate()
            # self.visualize()

    def retriangulate(self):
        print("Retriangulating")
        for side in ['left', 'right']:
            for i in range(self.processed_imgs[side]):
                ptrs_idxs = np.where(self.imgs[side][i].X_ptrs != -1)[0].astype(int)
                if len(ptrs_idxs) == 0:
                    continue
                X = self.X[self.imgs[side][i].X_ptrs[ptrs_idxs]]
                p = self.imgs[side][i].p[ptrs_idxs]

                P = self.get_P(side, i)

                X = np.concatenate([X, np.ones([len(X), 1])], axis=1)
                pp = (P @ X.T).T
                pp = pp[:, :2] / pp[:, 2, np.newaxis]
                dist = np.linalg.norm(p - pp, axis=1)

                bad_idxs = np.where(dist > self.tol)[0].astype(int)
                self.imgs[side][i].X_ptrs[ptrs_idxs[bad_idxs]] = -1

    def init_pose(self):
        # Init the model from 2 first left images with different poses
        self.init_pose_left()

        # Then we estimate the relative position of the left and right camera
        # This order is necessary to recover the scale
        self.init_rig_pose()
        self.add_new_view_right()
        self.processed_imgs['right'] += 1

    def visualize(self):
        # fig = plt.figure(figsize=(12, 12))
        # ax = fig.add_subplot(projection='3d')
        # ax.scatter(self.X[:, 0], self.X[:, 1], self.X[:, 2], c=self.bgrs[:, ::-1]/255)
        # print(len(self.X))
        # plt.show()

        X = np.ones(4)

        for i in range(self.processed_imgs['left']):
            for side in ['left', 'right']:
                if i >= self.processed_imgs[side]:
                    continue
                img = self.imgs[side][i]
                vis_img = np.copy(img.img)
                P = self.get_P(side, i)
                for j in range(len(img.p)):
                    vis_img = cv2.circle(vis_img, (int(img.p[j, 0]), int(img.p[j, 1])), 3, (0, 0, 255), thickness=-1)
                    if img.X_ptrs[j]!=-1:
                        X[:3] = self.X[img.X_ptrs[j]]
                        p = P @ X
                        p = p[:2] / p[2]

                        vis_img = cv2.circle(vis_img, (int(p[0]), int(p[1])), 10, (0, 255, 0), thickness=-1)

                cv2.imshow("Img {} {}".format(side, i), cv2.resize(vis_img, (img.scaled_dims(4))))

        cv2.waitKey(0)
        cv2.destroyAllWindows()

    def get_P_left(self, i):
        return self.camera_l.calibration_matrix() @ self.poses[i].Rt

    def get_P_right(self, i):
        Rt_rig = np.zeros([4, 4])
        Rt_rig[3, 3] = 1
        Rt_rig[:3, :3] = self.rig_pose[0].R
        Rt_rig[:3, 3] = self.rig_pose[0].t

        Rt_camera = np.zeros([4, 4])
        Rt_camera[3, 3] = 1
        Rt_camera[:3, :3] = self.poses[i].R
        Rt_camera[:3, 3] = self.poses[i].t

        Rt = Rt_rig @ Rt_camera

        # R = self.rig_pose[0].R @ self.poses[i].R
        # t = self.rig_pose[0].t + self.poses[i].t
        # Rt = np.zeros([3, 4])
        # Rt[:3, :3] = R
        # Rt[:, 3] = t

        return self.camera_r.calibration_matrix() @ Rt[:3, :]

    def get_P(self, side, i):
        if side == 'left':
            return self.get_P_left(i)
        return self.get_P_right(i)

    def init_pose_left(self):
        # Calculate the initial pose between two positions of the same camera to create the base model

        p_1_idxs, p_2_idxs = match(self.imgs['left'][0].des, self.imgs['left'][1].des, self.imgs['left'][0].p, self.imgs['left'][1].p, min_dist=5.0)

        p_1 = self.imgs['left'][0].p[p_1_idxs]
        p_2 = self.imgs['left'][1].p[p_2_idxs]

        ransac_dict = {'refine': False, 'refine_final': False}
        # ransac_dict = {'refine': False, 'refine_final': False, 'min_iterations': 10000}

        # pose, info = poselib.estimate_relative_pose(p_1, p_2, self.camera_l_dict, self.camera_l_dict, ransac_opt=ransac_dict)
        # print("5pt Essential")
        # print_pose(pose)
        # print(20 * '*')

        # pose, info = poselib.estimate_relative_planar_pose(p_1, p_2, self.camera_l_dict, self.camera_l_dict, ransac_opt=ransac_dict)
        # print("4pt Planar Essential")
        # print_pose(pose)
        # print(20 * '*')

        pose, info = poselib.estimate_relative_planar_pose_brute(p_1, p_2, self.camera_l_dict, self.camera_l_dict, ransac_opt=ransac_dict)
        print("5pt Essential Planar Brute")
        print_pose(pose)
        print(20 * '*')

        init_pose = poselib.CameraPose()
        init_pose.R = np.eye(3)
        init_pose.t = np.zeros(3)

        self.poses.append(init_pose)

        self.poses.append(pose)

        correct_idxs = np.where(info['inliers'])
        direct_idxs_1 = p_1_idxs[correct_idxs]
        direct_idxs_2 = p_2_idxs[correct_idxs]

        correct_p_1 = self.imgs['left'][0].p[direct_idxs_1]
        correct_p_2 = self.imgs['left'][1].p[direct_idxs_2]        

        X = cv2.triangulatePoints(self.get_P_left(0), self.get_P_left(1), correct_p_1.T, correct_p_2.T).T
        X = X[:, :3] / X[:, 3, np.newaxis]

        X_indices = np.arange(len(self.X), len(self.X) + len(X))
        
        self.imgs['left'][0].X_ptrs[direct_idxs_1] = X_indices
        self.imgs['left'][1].X_ptrs[direct_idxs_2] = X_indices
        
        self.X = np.array(X)
        self.bgrs = self.imgs['left'][0].bgrs[direct_idxs_1]
        self.processed_imgs['left'] = 2

    def init_rig_pose(self):
        # Get the position of the two stereo cameras w.r.t each other
        p_l_idxs, p_r_idxs = match(self.imgs['left'][0].des, self.imgs['right'][0].des, self.imgs['left'][0].p, self.imgs['right'][0].p,
                                   min_dist=0.0)

        X_idxs = np.array([self.imgs['left'][0].X_ptrs[l_idx] for l_idx in p_l_idxs if l_idx != -1])
        p_idxs = np.array([r_idx for l_idx, r_idx in zip(p_l_idxs, p_r_idxs) if l_idx != -1])

        p3d = self.X[X_idxs]
        p2d = self.imgs['right'][0].p[p_idxs]

        ransac_dict = {'refine': True, 'refine_final': True, 'max_reprojection_error': self.tol}
        pose, info = poselib.estimate_absolute_pose(p2d, p3d, self.camera_r_dict, ransac_dict)

        self.rig_pose[0] = pose

        print("Init Rig Pose")
        print_pose(pose)

        correct_idxs = np.where(info['inliers'])[0].astype(int)
        direct_p_idxs = p_idxs[correct_idxs]
        self.imgs['right'][0].X_ptrs[direct_p_idxs] = X_idxs[correct_idxs]

        p_left_idxs, p_right_idxs = match(self.imgs['left'][1].des, self.imgs['right'][0].des)

        P_right = self.get_P('right', 0)

        X_idxs = np.array([self.imgs['left'][1].X_ptrs[i] for i in p_left_idxs if self.imgs['left'][1].X_ptrs[i] != -1])
        p_idxs = np.array([j for i, j in zip(p_left_idxs, p_right_idxs) if self.imgs['left'][1].X_ptrs[i] != -1])

        p3d = self.X[X_idxs]
        p3d = np.column_stack([p3d, np.ones(len(X_idxs))])
        p2d = self.imgs['right'][0].p[p_idxs]
        pp2d = (P_right @ p3d.T).T
        pp2d = pp2d[:, :2] / pp2d[:, 2, np.newaxis]

        correct_idxs = np.where(np.linalg.norm(pp2d - p2d, axis=1) < self.tol)[0].astype(int)
        print("In right {}-th image we added {} correspondences to the model".format(0, len(correct_idxs)))
        direct_p_idxs = p_idxs[correct_idxs]
        self.imgs['right'][0].X_ptrs[direct_p_idxs] = X_idxs[correct_idxs]

        # left_idxs = np.array([i for i in p_left_idxs if self.imgs['left'][1].X_ptrs[i] == -1])
        # right_idxs = np.array([j for i, j in zip(p_left_idxs, p_right_idxs) if self.imgs['left'][1].X_ptrs[i] == -1])
        #
        # self.triangulate_and_add('left', 'right', 1, 0, left_idxs, right_idxs)
        self.processed_imgs['right'] = 1

    def add_next_view(self):
        # Here we add another view
        # We start with the left view
        self.add_new_view_left()


        # Then we check the added right image
        self.add_new_view_right()

        # We increment the processed imgs now so the prev code does not consider the same position for triangulation

        self.processed_imgs['left'] += 1
        self.processed_imgs['right'] += 1

    def add_new_view_left(self):
        c = self.processed_imgs['left']

        # We extract matches first with all already processed images
        X_left_idxs, p_left_idxs, p_1eft_prev_new_idxs, p_left_cur_new_idxs = self.get_matches('left', 'left')
        X_right_idxs, p_right_idxs, p_right_prev_new_idxs, p_right_cur_new_idxs = self.get_matches('right', 'left')

        # Next we calculate the pose w.r.t the 1st left camera position using the matches between 3d model and 2d feats
        X_idxs = np.concatenate([X_left_idxs, X_right_idxs])
        p_idxs = np.concatenate([p_left_idxs, p_right_idxs])

        p3d = self.X[X_idxs]
        p2d = self.imgs['left'][c].p[p_idxs]

        ransac_dict = {'refine': False, 'refine_final': False, 'max_reprojection_error': self.tol}
        # pose, info = poselib.estimate_absolute_pose(p2d, p3d, self.camera_l_dict, ransac_dict)
        pose, info = poselib.estimate_absolute_planar_pose_brute(p2d, p3d, self.camera_l_dict, ransac_dict)
        self.poses.append(pose)

        # We register the correspondences
        correct_idxs = np.where(info['inliers'])[0].astype(int)
        print("In left {}-th image we added {} correspondences to the model".format(c, len(correct_idxs)))
        direct_p_idxs = p_idxs[correct_idxs]
        self.imgs['left'][c].X_ptrs[direct_p_idxs] = X_idxs[correct_idxs]

        # We triangulate new points using the remaining correspondences
        self.triangulate_new_pts('left', 'left', p_1eft_prev_new_idxs, p_left_cur_new_idxs)
        self.triangulate_new_pts('right', 'left', p_right_prev_new_idxs, p_right_cur_new_idxs)

    def add_new_view_right(self):
        c = self.processed_imgs['right']

        X_left_idxs, p_left_idxs, p_1eft_prev_new_idxs, p_left_cur_new_idxs = self.get_matches('left', 'right')
        X_right_idxs, p_right_idxs, p_right_prev_new_idxs, p_right_cur_new_idxs = self.get_matches('right', 'right')

        # We check which points correspond to the model by projecting the model pts a checking the distance to 2d pts
        X_idxs = np.concatenate([X_left_idxs, X_right_idxs])
        p_idxs = np.concatenate([p_left_idxs, p_right_idxs])

        p3d = self.X[X_idxs]
        p3d = np.column_stack([p3d, np.ones(len(X_idxs))])
        p2d = self.imgs['right'][c].p[p_idxs]
        pp2d = (self.get_P('right', c) @ p3d.T).T
        pp2d = pp2d[:, :2] / pp2d[:, 2, np.newaxis]

        correct_idxs = np.where(np.linalg.norm(pp2d - p2d, axis=1))[0].astype(int)
        print("In right {}-th image we added {} correspondences to the model".format(c, len(correct_idxs)))
        direct_p_idxs = p_idxs[correct_idxs]
        self.imgs['right'][c].X_ptrs[direct_p_idxs] = X_idxs[correct_idxs]

        # We triangulate new points using the remaining correspondences
        self.triangulate_new_pts('left', 'right', p_1eft_prev_new_idxs, p_left_cur_new_idxs)
        self.triangulate_new_pts('right', 'right', p_right_prev_new_idxs, p_right_cur_new_idxs)

    def triangulate_new_pts(self, prev_side, cur_side, p_prev_idxs, p_cur_idxs):
        # Adds new points to the model based on the correspondences
        # It expects that processed imgs in prev_side <= processed imgs in cur_side

        c = self.processed_imgs[cur_side]
        for i in range(self.processed_imgs[prev_side]):
            p_1_idxs = np.array(p_prev_idxs[i], dtype=int)
            p_2_idxs = np.array(p_cur_idxs[i], dtype=int)

            self.triangulate_and_add(prev_side, cur_side, i, c, p_1_idxs, p_2_idxs)

    def triangulate_and_add(self, prev_side, cur_side, prev_img_idx, cur_img_idx, prev_idxs, cur_idxs):
        P_c = self.get_P(cur_side, cur_img_idx)

        p_1 = self.imgs[prev_side][prev_img_idx].p[prev_idxs]
        p_2 = self.imgs[cur_side][cur_img_idx].p[cur_idxs]
        P = self.get_P(prev_side, prev_img_idx)
        X_t = cv2.triangulatePoints(P, P_c, p_1.T, p_2.T)
        pp_1 = (P @ X_t).T
        pp_1 = pp_1[:, :2] / pp_1[:, 2, np.newaxis]
        pp_2 = (P_c @ X_t).T
        pp_2 = pp_2[:, :2] / pp_2[:, 2, np.newaxis]
        err_1 = np.linalg.norm(p_1 - pp_1, axis=1)
        err_2 = np.linalg.norm(p_2 - pp_2, axis=1)
        good_idxs = np.where(np.logical_and(err_1 < self.tol, err_2 < self.tol))[0].astype(int)
        if len(good_idxs) == 0:
            return
        X = X_t[:, good_idxs].T
        X = X[:, :3] / X[:, 3, np.newaxis]
        X_idxs = np.arange(len(self.X), len(self.X) + len(X))
        self.X = np.row_stack([self.X, X])
        self.imgs[prev_side][prev_img_idx].X_ptrs[prev_idxs[good_idxs]] = X_idxs
        self.imgs[cur_side][cur_img_idx].X_ptrs[cur_idxs[good_idxs]] = X_idxs
        self.bgrs = np.row_stack([self.bgrs, self.imgs[prev_side][prev_img_idx].bgrs[prev_idxs[good_idxs]]])

    def get_matches(self, prev, current):
        c = self.processed_imgs[current]

        X_indices = []
        p_resection_idxs = []
        p_new_prev_idxs = [[] for _ in range(self.processed_imgs[prev])]
        p_new_cur_idxs = [[] for _ in range(self.processed_imgs[prev])]
        for i in range(self.processed_imgs[prev]):
            p_prev_loc_idxs, p_cur_loc_idxs = match(self.imgs[prev][i].des, self.imgs[current][c].des)

            local_X_idxs = self.imgs[prev][i].X_ptrs[p_prev_loc_idxs]

            for j in range(len(local_X_idxs)):
                if local_X_idxs[j] != -1:  # and local_X_idxs[j] not in X_indices:
                    X_indices.append(local_X_idxs[j])
                    p_resection_idxs.append(p_cur_loc_idxs[j])
                else:
                    p_new_prev_idxs[i].append(p_prev_loc_idxs[j])
                    p_new_cur_idxs[i].append(p_cur_loc_idxs[j])

        X_indices = np.array(X_indices, dtype=int)
        p_resection_idxs = np.array(p_resection_idxs, dtype=int)

        return X_indices, p_resection_idxs, p_new_prev_idxs, p_new_cur_idxs

    def get_ba_problem(self, ):
        prob = pyceres.Problem()
        # loss = pyceres.TrivialLoss()
        loss = pyceres.HuberLoss(0.5)

        for i in range(self.processed_imgs['left']):
            for j in range(len(self.imgs['left'][i].X_ptrs)):

                if self.imgs['left'][i].X_ptrs[j] == -1:
                    continue

                cost = pyceres.factors.BundleAdjustmentCost(self.camera_l.model_id, self.imgs['left'][i].p[j])
                x_idx = np.copy(self.imgs['left'][i].X_ptrs[j])
                prob.add_residual_block(cost, loss, [self.poses[i].q, self.poses[i].t, self.X[x_idx], self.camera_l.params])

            if np.any(self.imgs['left'][i].X_ptrs != -1):
                prob.set_parameterization(self.poses[i].q, pyceres.QuaternionParameterization())



        # prob.set_parameter_block_constant(self.camera_l.params)

        for i in range(self.processed_imgs['right']):
            for j in range(len(self.imgs['right'][i].X_ptrs)):
                if self.imgs['right'][i].X_ptrs[j] == -1:
                    continue

                cost = pyceres.factors.BundleAdjustmentRigCost(self.camera_r.model_id, self.imgs['right'][i].p[j])
                x_idx = np.copy(self.imgs['right'][i].X_ptrs[j])
                prob.add_residual_block(cost, loss, [self.poses[i].q, self.poses[i].t, self.rig_pose[0].q, self.rig_pose[0].t, self.X[x_idx], self.camera_r.params])

                # prob.add_residual_block(cost, loss, [self.rig_pose[0].q, self.rig_pose[0].t, self.poses[i].q, self.poses[i].t, self.X[x_idx], self.camera_r.params])
            if np.any(self.imgs['right'][i].X_ptrs != -1):
                prob.set_parameterization(self.poses[i].q, pyceres.QuaternionParameterization())

        # if self.processed_imgs['right']:
        #     prob.set_parameterization(self.rig_pose[0].q, pyceres.QuaternionParameterization())

        return prob

    def bundle_adjust(self):
        print("Running bundle adjustment")
        print(self.rig_pose[0])
        prob = self.get_ba_problem()

        print(prob.num_parameter_bocks(), prob.num_parameters(), prob.num_residual_blocks(), prob.num_residuals())
        options = pyceres.SolverOptions()
        options.linear_solver_type = pyceres.LinearSolverType.DENSE_SCHUR
        options.minimizer_progress_to_stdout = True
        options.num_threads = -1

        summary = pyceres.SolverSummary()
        pyceres.solve(options, prob, summary)
        print(self.rig_pose[0])
        print(summary.BriefReport())
        self.update()


def match(d_1, d_2, p_1=None, p_2=None, min_dist=5.0):
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches_orig = flann.knnMatch(d_1, d_2, k=2)
    matches = []
    for i, (m, n) in enumerate(matches_orig):
        if m.distance < 0.7 * n.distance:
            if p_1 is None or p_2 is None:
                matches.append(m)
            else:
                dist = np.linalg.norm(p_1[m.queryIdx] - p_2[m.trainIdx])
                if dist > min_dist:
                    matches.append(m)

    d_1_idx = np.array([m.queryIdx for m in matches])
    d_2_idx = np.array([m.trainIdx for m in matches])

    return d_1_idx, d_2_idx

def print_pose(pose):
    from scipy.spatial.transform import Rotation
    def skew(x):
        return np.array([[0, -x[2], x[1]],
                         [x[2], 0, -x[0]],
                         [-x[1], x[0], 0]])

    E = pose.R @ skew(pose.t)
    print("det(E + E^T)", np.linalg.det(E + E.T))

    R = Rotation.from_matrix(pose.R)
    v = R.as_rotvec()
    print("Rotvec: ", v)

    angle = np.arccos(np.dot(v, pose.t) / (np.linalg.norm(v) * np.linalg.norm(pose.t)))
    print("Degrees:", np.rad2deg(angle))


if __name__ == '__main__':
    calib_path = 'D:/Research/data/NICO/calib_data.npy'
    img_dir = 'D:/Research/data/NICO/objects/sugar'

    model = ReconstructionModel(calib_path)
    model.load_images(img_dir)
    model.reconstruct()
    model.visualize()
