import argparse
import os
import cv2

from utils import get_undistort_functions, load_calib_data, get_l_r_image_fnames, load_l_r_images_undistorted


def init_bg_sub(images):
    bg_sub = cv2.bgsegm.createBackgroundSubtractorMOG()
    for img in images:
        bg_sub.apply(img)

    return bg_sub


def save_undistorted_masked_images(calib_npy_path, img_dir, out_dir, scale=4):
    calib_dict = load_calib_data(calib_npy_path)

    print("Calib dict loaded")
    print(calib_dict)


    imgs_l, imgs_r, fnames_l, fnames_r = load_l_r_images_undistorted(calib_dict, img_dir, ret_fnames=True)

    orig_dims = (imgs_l[0].shape[1], imgs_l[0].shape[0])
    mini_dims = (orig_dims[0] // scale, orig_dims[1] // scale)

    imgs_l_small = [cv2.resize(img, mini_dims) for img in imgs_l]
    imgs_r_small = [cv2.resize(img, mini_dims) for img in imgs_r]

    bg_sub_l = init_bg_sub(imgs_l_small)
    bg_sub_r = init_bg_sub(imgs_r_small)

    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    mask_dir = os.path.join(out_dir, 'masks')
    if not os.path.exists(mask_dir):
        os.makedirs(mask_dir)

    for img_l, img_r, img_l_small, img_r_small, fname_l, fname_r in zip(imgs_l, imgs_r, imgs_l_small, imgs_r_small, fnames_l, fnames_r):
        fg_l = bg_sub_l.apply(img_l_small)
        fg_r = bg_sub_r.apply(img_r_small)

        fg_l[:mini_dims[1]//2, :] = 0
        fg_r[:mini_dims[1]//2, :] = 0

        element_erode = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        element_dilate = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))

        fg_l = cv2.erode(fg_l, element_erode)
        fg_r = cv2.erode(fg_r, element_erode)

        fg_l = cv2.dilate(fg_l, element_dilate)
        fg_r = cv2.dilate(fg_r, element_dilate)

        fg_l = cv2.resize(fg_l, orig_dims)
        fg_r = cv2.resize(fg_r, orig_dims)

        # img_l = cv2.bitwise_and(img_l, img_l, mask=fg_l)
        # img_r = cv2.bitwise_and(img_r, img_r, mask=fg_r)

        cv2.imwrite(os.path.join(out_dir, os.path.basename(fname_l)), img_l)
        cv2.imwrite(os.path.join(out_dir, os.path.basename(fname_r)), img_r)

        cv2.imwrite(os.path.join(mask_dir, os.path.basename(fname_l) + '.png'), fg_l)
        cv2.imwrite(os.path.join(mask_dir, os.path.basename(fname_r) + '.png'), fg_r)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('calib_path', type=str, help='path to calibration npy file')
    parser.add_argument('img_dir', type=str, help='directory where the calibration pickle gets saved to')
    parser.add_argument('out_dir', type=str, help='directory where the calibration pickle gets saved to')
    parser.add_argument('-d', '--debug', type=int, default=0, help='whether to debug 1 shows calib images, 2 lets you see the undistorted calib files')
    args = parser.parse_args()

    return args


if __name__ == '__main__':
    args = parse_args()
    # save_undistorted_masked_images('D:/Research/data/NICO/calib_data.npy', 'D:/Research/data/NICO/objects/robot',
    #                                'D:/Research/data/NICO/objects/undistorted_robot')

    save_undistorted_masked_images(args.calib_path, args.img_dir, args.out_dir)